const {Given, When, Then} = require('cucumber');
const signinPage = require('../../../pages/ui/signInPageObjects');
this.World = require('../../../support/world');

Given(/^I am on the page titled "([^"]*)"$/, function(title) {
    return signinPage.navigateToLogin(this, title);
});

When(/^I enter the credentials for the user "([^"]*)" on the login page$/, function (account) {
    return signinPage.enterCredentials(this, account);
});

When(/^I click the sign in button on the login page$/, function() {
    return signinPage.clickSignInButton(this);
});

When(/^I should see the landing page titled "pageTitle"$/, function(pageTitle) {
    return signinPage.verifyLoginLandingPage(this, pageTitle);
});
