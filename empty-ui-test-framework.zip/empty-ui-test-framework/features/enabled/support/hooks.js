/**
 * Hooks are used for setup and teardown of the environment before and after each scenario.
 *
 * - Multiple **Before** hooks are executed in the order that they were defined.
 * - Multiple **After** hooks are executed in the reverse order that they were defined.
 *
 * For more information on hooks see [Hooks JS]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/hooks.md}.
 *
 * @requires module:config
 * @module hooks
 */
const {After, Before, Status} = require('cucumber');
/**
 * Instance of the [argopts]{@link module:server.argopts}.
 *
 * @memberOf module:hooks
 */
const argopts = require('yargs').parse(process.argv);
/**
 * Instance of the [config]{@link module:config}.
 *
 * @memberOf module:hooks
 */
const config = require('../../../package.json').config;
/** Firstly, apply any command line argument option overrides. */
Object.assign(config, argopts);
/** Secondly, merge in any command-line World parameters. */
Object.assign(config, JSON.parse((argopts.worldParameters || '{}')));
/** Set various default configurations. */
config.application = config.application || 'mxc';


/** Before scenario to designate specific tests as skipped. This prevents test execution and does not set a failure in the report. */
Before({tags: '@wip or @skip', order: 0}, (scenario, callback) => callback(null, 'skipped'));

/** If we're running `prod` tests, skip tests _not_ marked as `@prod`. */
if (config.target === 'prod') Before({tags: `not @${config.target}`}, (scenario, callback) => callback(null, 'skipped'));

// for debugging
// Before(async function (scenario) {
//     await console.log('BEGIN: ' + scenario.pickle.name);
// });

/** After hook to handle test failures. This causes screenshots to be attached to the cucumber run report when there is a failure. */
After({order: 1}, async function (scenario) {
    const world = this;
    if (world.driver) {
        if (scenario.result.status === Status.FAILED) {
            /** if the report type is cucumber then take a screen shot and attach it to the report when a test fails */
            if (config.reporter.takeScreenShot === true) {
                return world.driver.takeScreenshot().then(async function (screenshot) {
                    world.attach(screenshot, 'image/png');
                    if (config.browser.closeOnFail === true) {
                        try {
                            // for debugging
                            // console.log('Failure: ' + scenario.pickle.name);
                            await world.driver.quit();
                        } catch (e) {
                            console.log(e);
                        }
                    }
                });
            } else {
                if (config.browser.closeOnFail === false || config.environment === 'grid') {
                    try {
                        await world.driver.quit();
                    } catch (e) {
                        console.log(e);
                    }
                }
            }
        } else {
            try {
                //for debugging
                // console.log('Pass: ' + scenario.pickle.name);
                await world.driver.quit();
            } catch (e) {
                console.log(e);
            }
        }
    }
});

