#!/usr/bin/env node
/* eslint-disable no-console */
const nodePackage = require('./package.json');
const config = nodePackage.config;
const {execSync} = require('child_process');
const path = require('path');
const working = path.dirname(process.argv[1]);
const fs = require('fs');
const timestamp = require('moment')().format('MM-DD-HHmm');
const {each} = require('lodash');
const argopts = require('yargs').option({
    'tags': {type: 'array', desc: 'Enter multiple tags to run multiple tests'},
    'grid': {type: 'boolean',  default: config.grid}
}).argv
const launchReport = argopts.hasOwnProperty('launchReport') ? (/true/i).test(argopts.launchReport) : undefined;
const axios = require('axios');

/**create a properly formatted string of tags to run cucumber with. Proper format: --tags '(@TEST000137 or @TESTU00033)' */
let tagString;
if (argopts.hasOwnProperty('tags')) {

    tagString = '--tags \'('
    for (let i = 0; i < argopts.tags.length; i++) {
        tagString = tagString + argopts.tags[i];

        if (i < (argopts.tags.length - 1)) {
            tagString = tagString + ' or '
        }
    }
    tagString = tagString + ')\''
}

/** apply any command line argument option overrides. */
Object.assign(config, argopts);
config.browser = config.browser || {};
config.reporter = config.reporter || {};


/** determine if we want to run on the grid, or locally */
config.grid = argopts.grid ? argopts.grid : config.grid;

/** determine what environment we want to run on, qa, uat, prod */
config.environment = argopts.environment ? argopts.environment : config.environment;

/** allow the ability to override closing the browser from command line*/
config.browser.closeOnFail = argopts.closeOnFail ? argopts.closeOnFail : config.browser.closeOnFail;

config.reporter.metadata = Object.assign(config.reporter.metadata || {}, {
    'App Version': nodePackage.version,
    'Product Tested': config.application.toUpperCase(),
    'Environment Tested': config.environment.toUpperCase(),
    'Browser': config.browser.name.replace(/.*/, (name) => name[0].toUpperCase() + name.substr(1).toLowerCase()) || 'Chrome',
});

config.reporter.launchReport = launchReport || config.reporter.launchReport;


/** The debugging port being used if `config.debug === true`.*/
let debug = '';

/** If we're in `--debug` mode delete the `--parallel` option so we can connect to the debugger and make sure to turn on debug mode for Node. */
if (config.debug) {
    delete config.parallel;
    debug += 'node --inspect=22772 ';
}

/** Setup an array to generate `--switch value` pairs for each command line option.*/
const keys = [];
if (config.parallel) keys.push('parallel');
if (config.debug) keys.push('debug');

/** ensure that we do not run locally with too many parallels **/
//if (!config.grid) {
//    console.info('Setting parallel to 1 so we do not overwhelm users laptop!');
//    config.parallel = "5";
//}

/** ensure that we do not run locally with too many parallels **/
if (config.grid) {
    console.info('Setting close on fail to true so we close browsers on the grid');
    config.browser.closeOnFail = true;
}

/** Concatenate all of the command line options into a single string.*/
let args = '';
/** Step through each argument... */
each(keys, (key) => {
    /** ...and create the `--switch value` pair for each. */
    args += `--${key} ${config[key]} `;
});


/** this is an ugly way to append the tagstring into the full command run later */
if (tagString) {
    args += tagString;
}


/** create the world object to share with any parallel browsers */
const world = JSON.stringify(config);

/** Create the `Cucumber` command... */

const reportPath = './reports';

/**Create a project folder if it does not exist to store the generated json report */
if (!fs.existsSync(reportPath)) {
    fs.mkdirSync(reportPath);
}

const reportFormat = `json:${reportPath}/${config.application}-${timestamp}.json`;

async function startCucumber() {

    /** display runtime options for cucumber in terminal */
    console.info('\nExecuting cucumber tests with runtime options:\n');

    Object.keys(config).forEach((key) => {
        if (typeof config[key] !== 'object') {
            if (config[key] !== 'server.js') {
                console.info(`\t${key} = ${config[key]}`);
            }
        }
        if (key === 'tags') {
            console.info(`\t${key} = ${config.tags.toString()}`);
        }
    });

    if (config.browser) {
        Object.keys(config.browser).forEach((browserKey) => {
            console.info(`\t${browserKey} = ${config.browser[browserKey]}`);
        });
    }

    if (config.grid.toString().toLowerCase() === 'true') {
        // check if the grid is able to handle our test run. Stop if it is too busy.
        await gridStatus();
    } else {
        console.info(`\nSkipping grid check since gridStatus = ${config.grid}`);
    }

    /**create and execute the cucumber command */
    const command = `${debug}./node_modules/.bin/cucumber-js ` +
        `--require ${working}/features/enabled ` +
        `--format ${reportFormat} ${working}/features/enabled ` +
        `--world-parameters '${world}' ` +
        `--format-options '{"colorsEnabled": true}' ` +
        `--retry ${config.retries} ` +
        `--strict ` +
        `--exit ` +
        args;

    execSync(command, {stdio: 'inherit'});

    console.info(`\ndone`)
}


async function reportCucumber() {
    /**execute the report command */
    try {
        if (config.reporter.launchReport === true) {
            /** Create the `reporter` command. */

            const command = `${working}/bin/reporter ` +
                `--timestamp ${timestamp} ` +
                `--config '${JSON.stringify(config)}'`  //<-- pass the config object to report.js

            execSync(command, {stdio: 'inherit'});
        }
        //I put a blank line here because it makes terminal look better
        console.info('\n');
    } catch (e) {
        console.info('Unable to generate HTML report due to errors! \n');
        throw e;
    }
}

async function gridStatus() {

    const gridSession = await axios.create({
        baseURL: config.gridUrl,
        timeout: 20000,
        validateStatus: (status) => status >= 200,
        headers: {'Content-Type': 'application/json'}
    });

    let gridData = await gridSession({
        url: '/grid/api/hub/',
        method: 'get'
    });

    console.info(`\nChecking if grid has at least ${config.parallel} open slots...`);
    if (gridData.data.slotCounts.free < config.parallel) {
        console.info('The grid is busy, please wait until it is no longer in use before running tests.');
        process.exitCode = 1;
        process.exit();
    } else {
        console.info(`The grid has ${gridData.data.slotCounts.free} open slots`);
    }
}

// for debugging.
process.on('exit', async function(code) {
    console.info(`Process exit code = ${code}`);
    console.info(`Cucumber execution completed with total execution time = ${new Date(process.uptime() * 1000).toISOString().substr(11, 8)}`);
});

process.on('unhandledRejection', async function(error) {
    await console.error('Unhandled rejection', error);
});


async function run() {
    /** DO all the things! */
    await startCucumber();
}

run().then(
    async () => {
        console.log('PASS RUN CUCUMBER');
        // report test results after successful cucumber execution
        await reportCucumber();
        process.exit();
    },
    async (err) => {
        // report test results after cucumber execution failure 
        await reportCucumber();
        //for debugging
        // console.log(err);
        process.exitCode = 1;
        process.exit();
    }
);
