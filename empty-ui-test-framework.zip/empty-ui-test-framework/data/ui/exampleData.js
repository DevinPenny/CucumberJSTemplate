module.exports = () => ({
    tableHeaders: [
        'column1',
        'column2',
        'column3',
    ],
});