/**
 * User and environment data for testing.
 *
 * @property {object} standard - A user with standard roles and permissions.
 * @property {string} standard.id - The id for the standard user.
 * @property {string} standard.pass - The password for the standard user.
 * @memberOf module:environmentData
 */
const users = {

    user1: {
        id: 'user1',
        pass: 'user2',
        apiKeys: {
            qa: 'QA_KEY_GOES_HERE',
            uat: 'UAT_KEY_GOES_HERE',
            sandbox: 'SB_KEY_GOES_HERE',
            prod: 'PROD_KEY_GOES_HERE',
        },
    },
    user2: {
        id: 'user2',
        pass: 'user2',
        apiKeys: {
            qa: 'QA_KEY_GOES_HERE',
            uat: 'UAT_KEY_GOES_HERE',
            sandbox: 'SB_KEY_GOES_HERE',
            prod: 'PROD_KEY_GOES_HERE',
        },
    }
};

/**
 * Data used during tests.
 * 
 * @module environmentData
 */
module.exports = {
    local: {
        domain: 'http://localhost:8080',
        apiDomain: 'http://localhost:8080/',
        users: users,
    },
    qa: {
        domain: 'https://qa.url.com',
        apiDomain: 'https://qa.api.url.com',
        users: users,
    },
    uat: {
        domain: 'https://uat.url.com/',
        apiDomain: 'https://uat.api.url.com',
        users: users,
    },
    sandbox: {
        domain: 'https://sandbox.url.com/',
        apiDomain: 'https://sandbox.api.url.com',
        users: users,
    },
    prod: {
        domain: 'https://url.com/',
        apiDomain: 'https://api.url.com',
        users: users,
    },
};