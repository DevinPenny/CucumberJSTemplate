
/**
 * File to store a bunch of supportive data. Mainly used for the corresponding utils file so the methods don't need to accept non-variable params
 * Also briefly used in some main test files for info if needed
 **/

const route = {
    route1: '/checkout/v3/batch',
    route2: (id) => `/checkout/v3/batch/${id}`,
};

const payload = {
};

module.exports = {
    route,
    payload
};