'use strict';

module.exports = {
    'source': {
        'includePattern': '^(.*\.(js(doc|x)?)$)?[^.]*$',
        'include': ['README.md'],
        'excludePattern': '(^|\\/|\\\\)_',
        'exclude': ['node_modules']
    },
    'plugins': ['plugins/markdown'],
    'markdown': {
        'idInHeadings': true
    },
    'templates': {
        'theme': 'spacelab',
        'systemName' : 'QA Automation',
        'copyright': 'Copyright © 2017-2018 PPS',
        'includeDate': false,
        'linenums': true,
        'inverseNav': true,
        'outputSourceFiles': true,
        'outputSourcePath': true,
        'sort': false,
        'search': true,
        'methodHeadingReturns': false
    },
    'opts': {
        'destination': './test/automation/docs/',
        'template': './node_modules/ink-docstrap/template',
        'recurse': true
    }
};