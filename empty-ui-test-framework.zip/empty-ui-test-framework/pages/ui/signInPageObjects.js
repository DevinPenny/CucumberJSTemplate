const {By} = require('selenium-webdriver');
const get = require('lodash/get');
const Page = require('../baseObjects');


/**
 * Locators used to manipulate and test login page. For more information on elements see: [Selenium Locators]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/index_exports_By.html}
 *
 * @property {By.id} signInButton - Button to expose the user login options of the main page.
 * @property {By.id} nameField - User name field on the login page.
 * @property {By.id} passField - Password field on the login page.
 * @property {By.css} loginButton - The login button on the login page.
 * @property {By.css} loginError - Locator to find any login errors, used after attempting to log in.
 * @property {By.css} loginMessage - Locator to find the success message after attempting to log in.
 *
 * @memberOf module:mxmLoginPage
 */
const elements = {
    signInButton: By.id('signinLink'),
    nameField: By.id('username'),
    passField: By.id('password'),
    loginError: By.css('[class*="toast-message"]'),
    loginMessage: By.css('div[class*="--pageTitle"]'),
    loginForm: By.id('loginForm'),
    topNavigationBar: By.id('toggleNavController')
};

/**
 * Provides methods used on the application login page. This is for the MXM application.
 *
 * @module mxmLoginPage
 */
module.exports = {
    /**
     * Uses the [navigateToPage]{@link module:baseObjects.navigateToPage} method to check the title of the current page.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {string} title - The HTML page title expected.
     * @return {Promise} The result of the [navigateToPage]{@link module:baseObjects.navigateToPage} method.
     */
    navigateToLogin: (world, title) => Page.navigateToPage(world, `${world.envData.domain}/login`, title, elements.signInButton).then(() => {
        Page.waitToBeVisible(world, elements.signInButton);
        Page.waitSeconds(world, 2);
    }),

    /**
     * Enter the username and password for the account specified.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {string} account - The account type to log into the application with
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the user credentials have been entered on the page.
     */
    enterCredentials: (world, account) => Page.waitToBeVisible(world, elements.nameField).then(() => {
        Page.enterText(world, elements.nameField, get(world.envData, `users.${account}.id`, ''));
        Page.enterText(world, elements.passField,  get(world.envData, `users.${account}.pass`, ''));
    }),

    /**
     * Click on the sign in button and wait for the user login menu to appear
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the login options are visible on the page.
     */
    clickSignInButton: (world) => Page.clickElement(world, elements.signInButton).then(() => {
        //wait a few seconds for page animations
        Page.waitSeconds(world, 3);
    }),

    /**
     * Click on the sign in button and wait for the user login menu to appear
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the login options are visible on the page.
     */
    verifyLoginLandingPage: (world) =>  Page.waitSeconds(world, 3).then(() => {
        Page.waitToBeLocated(world, elements.someLocator);
    }),


};
