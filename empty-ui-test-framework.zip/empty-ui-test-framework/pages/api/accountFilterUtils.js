const checkoutData = require('../data');


module.exports = {

    getData: (session, data) => {
        const url = checkoutData.route.accountFilter;
        return session({
            url: url,
            method: 'get',
            params: {
                ...data
            }
        });
    },
    putAccountFilter: (session, data, userId) => {
        const url = checkoutData.route.accountFilter;
        return session({
            url: url,
            method: 'post',
            data: data,
            //echo: true makes the API return the posted or put data
            params: {
                name: 'taxesReportFilter',
                id: userId
            }
        });
    },
    postAccountFilter: (session, data, userId) => {
        const url = checkoutData.route.accountFilter;
        return session({
            url: url,
            method: 'post',
            data: data,
            //echo: true makes the API return the posted or put data
            params: {
                name: 'taxesReportFilter',
                id: userId
            }
        });
    },
};