const {until, promise, Key} = require('selenium-webdriver');
const get = require('lodash/get');
const chai = require('chai');
const expect = chai.use(require('chai-as-promised')).expect;
chai.use(require('chai-as-promised')).should();
const moment = require('moment');
const {v4: uuid} = require('uuid');
/**
 * Framework configuration options.
 *
 * @property {string} application - The PPS application being tested.
 * @property {string} target - The application environment tests are targeting.
 * @property {string} environment - The framework environment tests are being run on.
 * @property {object} browser - Browser name and options.
 * @property {string} browser.name - The flavor of browser being used for tests.
 * @property {object} reporter - Options passed to the [Cucumber HTML Reporter]{@link https://npmjs.com/package/cucumber-html-reporter} output generator.
 * @property {boolean} [reporter.launchReport=true] - Whether to open the report output in the default browser or not.
 * @property {boolean} [reporter.storeScreenshots=false] - Whether to save screenshots or not.
 * @property {string} [reporter.screenshotsDirectory='test/automation/reports/screenshots/'] - Path to store screenshots under.
 * @property {string} [reporter.name='Test Results for <config.application> Project'] - The report name at the top center of the report. Includes the [`config.application`]{@link module:config.application} (from above) being tested.
 * @property {string} [reporter.brandTitle='QA Automation Testing Framework'] - The branding at the top left of the report.
 * @property {object} [reporter.metadata] - An object of `'Heading': 'Content'` pairs displayed in the collapsible *Metadata* section of the report.
 * @property {string} [reporter.theme='bootstrap'] - The named layout used for the report.
 * @typedef {object} config
 * @module config
 */


/**
 * Provides standard methods for page manipulation. All page objects should use base page methods instead of accessing selenium directly.
 */
module.exports = {
    /**
     * Resolve a step after performing any necessary conditional checks.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {*} result - The result of the original Promise, passed through as-is.
     * @return {Promise} A resolved Promise.
     */
    resolveStep: (world, result) => Promise.resolve(result),

    /**
     * Reject a step after performing any necessary conditional checks.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {SkippedError} error - The error generated in the step.
     * @return {Promise} A rejected Promise.
     */
    rejectStep: (world, error) => {
        if (error.name === 'SkippedError') {
            world.attach(error.message);
            return Promise.resolve('skipped');
        }
        return Promise.reject(error);
    },

    /**
     * Command the browser to navigate to a specific page.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {string} url - The application page to visit.
     * @param {string} [title=''] title - An optional string used to validate the page title after navigating to the page.
     * @param {object} wait - An optional element to wait on before checking the page title.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the page being visited has the expected title.
     */
    navigateToPage: (world, url, title = '', wait = '') => world.driver.get(url).then(() => Promise.all([
        (wait !== '') ?
            module.exports.waitToBeVisible(world, wait, `The page element was not located after navigating to the url ${url}`) : Promise.resolve(),
        (title !== '') ?
            world.driver.getTitle().should.become(title, 'The page title is not correct') : Promise.resolve()
    ])),

    /**
     * Verify that a page url contains an expected string
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {string} url - The application page to visit.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the page being visited has the expected title.
     */
    verifyPageUrl: (world, url) => world.driver.getCurrentUrl().should.eventually.contain(url, 'The page url is not correct'),

    /**
     * Wait for a specific number of seconds. This should not be heavily used.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {number} seconds - The number of seconds to wait.
     * @return {Promise} A Promise that will be resolved when the specified seconds have passed.
     */
    waitSeconds: (world, seconds) => world.driver.sleep(1000 * seconds),

    /**
     * Clear an input field, then enter text into the field.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that identifies the input box to enter text into.
     * @param {string} text - The text to put in the input field.
     * @param {boolean} [ignore=false] - Set this parameter to true if the field should not be cleared (date fields) or the value is reformatted after entry. Example: Phone number 1112223333 becomes (111) 222-3333
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the text in the input field is what we expected.
     */
    enterText: (world, locator, text, ignore = false) => (text === '')
        ? Promise.reject('Could not find the information')
        : module.exports.waitToBeVisible(world, locator, `Could not locate the input field: ${locator}`).then((input) => {
            if (!ignore) {
                input.clear(); //.then(() => input.getAttribute('value').should.become('', `Could not clear the input field: ${locator}`));
            }
            input.sendKeys(text).then(() => {
                if (!ignore) {
                    input.getAttribute(); //('value').should.become(text, `Could not enter the text in the field: ${text}`);
                }
            });
        }
        ),

    /**
     * Retrieves the relative time frame and input value and compares the calculated date to the date reported by the UI.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} timeFrameInput - The {@link WebDriver} method that identifies the input box for the relative time amount.
     * @param {method} timeFrameSelect - The {@link WebDriver} method that identifies the `<select />` dropdown representing the relative time frame.
     * @param {method} timeFrameLabel - The {@link WebDriver} method that identifies the element containing the calculated relative date and time.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the relative date has been set.
     */
    checkDateRange: (world, timeFrameInput, timeFrameSelect, timeFrameLabel) => {
        let units = {}, timeFrom = '';
        const start = moment();
        world.driver.findElement(timeFrameInput).getAttribute('value').then((timeFrameValue) => {
            timeFrameValue = parseInt(timeFrameValue);
            units = {
                's': {text: 'Seconds ago', range: {seconds: timeFrameValue}},
                'm': {text: 'Minutes ago', range: {minutes: timeFrameValue}},
                'h': {text: 'Hours ago', range: {hours: timeFrameValue}},
                'd': {text: 'Days ago', range: {days: timeFrameValue}},
                'w': {text: 'Weeks ago', range: {weeks: timeFrameValue}},
                'M': {text: 'Months ago', range: {months: timeFrameValue}},
                'y': {text: 'Years ago', range: {years: timeFrameValue}},
            };
            world.driver.findElement(timeFrameSelect).getAttribute('value').then((timeFrameRange) => {
                timeFrom = 'From: ' + start.subtract(units[timeFrameRange].range).format('YYYY-MM-DD');
                module.exports.expectTextContains(world, timeFrameLabel, timeFrom).then(() => {
                }, (error) => {
                    return Promise.reject(`When adjusting the time range, the new value '${timeFrom}' ` +
                        `does not match the expected value '${error.actual.slice(0, 16)}'`);
                });
            });
        });
    },

    /**
     * Wait for an element to be displayed on the page.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that identifies the element to be visible.
     * @param {string} [message=''] - The custom error message, meant to indicate the true nature of the error as opposed to a missing element.
     * @param {int} [locateWait=25000] - The number of milliseconds to wait for the element to be located.
     * @param {int} [visibleWait=25000] - The number of milliseconds to wait for the element to be visible.
     * @return {WebElement} The [Selenium WebElement]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/lib/webdriver_exports_WebElement.html} you were waiting to be visible.
     */
    waitToBeVisible: (world, locator, message = '', locateWait = 25000, visibleWait = 25000) => world.driver.wait(
        until.elementLocated(locator), locateWait
    ).then((located) => world.driver.wait(
        until.elementIsVisible(located), visibleWait
    )).then(
        (visible) => visible,
        (error) => Promise.reject(Error(message !== '' ? message : error))),

    /**
     * Verify that all elements are visible on the page
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {object|Array<WebElement>} elements - The {@link WebDriver} method that locates the elements
     * @param {int} [locateWait=10000] - The number of milliseconds to wait for the element to be located.
     * @param {int} [visibleWait=1000] - The number of milliseconds to wait for the element to be visible.
     * @return {Promise} assert that every elements are visible on the page
     */
    verifyElements: (world, elements, locateWait = 10000, visibleWait = 1000) => {
        for (const key in elements) {
            if (elements.hasOwnProperty(key)) {
                world.driver.wait(until.elementLocated(elements[key]), locateWait).then((located) =>
                    world.driver.wait(until.elementIsVisible(located), visibleWait)).then(
                    (visible) => visible,
                    (error) => Promise.reject(`${key} element is not visible on the page\n` + error)
                );
            } else {
                return Promise.reject('No elements found in the locator object');
            }
        }
    },


    /**
     * Wait until all elements for a locator are not visible on the page.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {WebElement} targets - The [Selenium WebElement]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/lib/
     * @param {int} [timeout=2500] - timeout(ms)
     * @param {String} error - error message when fails
     * @return {Promise}
     */
    waitToBeHidden: (world, targets, timeout = 25000, error = null) => module.exports.waitToBeVisible(world, targets, '', 2000, 2000).then(() =>
            world.driver.findElements(targets).then((elements) =>
                elements.map(element =>
                    world.driver.wait(until.elementIsNotVisible(element), timeout,
                        error ? 'Timeout: The element is still visible after ' + timeout / 1000 + ' seconds' : error))),
        () => Promise.resolve()),

    /**
     * Wait for an element to be located on the page.
     *
     * @example <caption>Method for accessing the HTML of an element...</caption>
     ).then((located) => {
    located.getDriver().executeScript('return arguments[0].outerHTML;', located).then((html) => {
        // eslint-disable-next-line no-console
        console.debug(html);
    });
}),
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that identifies the element to be located.
     * @param {string} [message=''] - The custom error message, meant to indicate the true nature of the error as opposed to a missing element.
     * @param {int} [locateWait=25000] - The number of milliseconds to wait for the element to be located.
     * @return {WebElement} The [Selenium WebElement]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/lib/webdriver_exports_WebElement.html} you were waiting to be located.
     */
    waitToBeLocated: (world, locator, message = '', locateWait = 25000) => world.driver.wait(
        until.elementLocated(locator), locateWait
    ).then(
        (located) => located,
        (error) => Promise.reject(Error(message !== '' ? message : error))
    ),

    /**
     * This is used for all mouse clicks.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that identifies the input box to enter text into.
     * @param {WebElement|boolean} [waitToBeVisible=false] - A [Selenium WebElement]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/lib/webdriver_exports_WebElement.html} that should be visible before clicking the `locator` item.
     * @param {string} [message=''] - The custom error message, meant to indicate the true nature of the error as opposed to a missing element.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the text in the input field is what we expected.
     */
    clickElement: (world, locator, waitToBeVisible = false, message = '') => {
        const which = (waitToBeVisible) ? waitToBeVisible : locator;
        return module.exports.waitToBeVisible(world, which, message).then((e) => {
            e.click();
            return e; //Return the element
        });
    },

    /**
     * Find all of the elements matching a selector, then compare the text of each element until a match is found. When a match is found, click on the element.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the list of elements being scanned for label.
     * @param {string} label - The text of the list item to be clicked.
     * @param {Boolean} ignoredCase - whether to ignore the list item case
     * @param {Boolean} exactMatch - whether to click on the first item that contain the given label
     * @param {string} [message=''] - The custom error message, meant to indicate the true nature of the error as opposed to a missing element.
     * @return {WebElement|Promise} Either the matching [WebElement]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/lib/webdriver_exports_WebElement.html} that was clicked or the [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that there was no matching element.
     */
    clickListItem: (world, locator, label, message = '', ignoredCase = true, exactMatch = true) =>
        module.exports.waitToBeVisible(world, locator, message).then(() => {
            const generic = `Unable to locate a clickable element '${label}'`;
            return module.exports.pickOne(world, locator, label, ignoredCase, exactMatch).then(
                (picked) => {
                    picked.click();
                    return picked;
                },
                () => Promise.reject(Error(message !== '' ? message : generic))
            );
        }),
    /**
     * Find the text of an element and compare it to a string.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the element whose text is being checked.
     * @param {string} text - The text that is expected.
     * @param {string} [message=''] - The custom error message, meant to indicate the true nature of the error as opposed to a missing element.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the element matches the expected text.
     */
    expectText: (world, locator, text, message = 'The text did not match') => module.exports.waitToBeVisible(world, locator).then((element) => {
        element.getText().should.become(text, message);
    }),

    /**
     * Find the text of an element and verify it contains a string.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the element to get the text from.
     * @param {string} text - The text to compare it to.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the page being visited has the expected title.
     */
    expectTextContains: (world, locator, text) => module.exports.waitToBeVisible(world, locator).then((element) => {
        element.getText().should.eventually.contains(text, 'The text did not contain the phrase');
    }),

    /**
     * Find all of the elements matching a locator, then compare the text of each element to a table list provided by a feature file.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the elements to check.
     * @param {object} table - The table provided by the feature file.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the page being visited has the expected title.
     */
    verifyFeatureTableContents: (world, locator, table) => module.exports.waitToBeVisible(world, locator).then(() => {
        const live = [];
        world.driver.findElements(locator).then((list) => list.map((item) => item.getText().then((text) => {
            live.push(text);
        }))).then(() => {
            expect(live, 'Lists do not match').to.have.ordered.members(table.rows().map((item) => item[0]));
        });
    }),

    /**
     * Find all of the elements matching a locator, then compare the text of each element to a an array provided by some sorurce.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the elements to check.
     * @param {array} values - an array of strings to verify against the locator array of strings.
     * @param {string} message - an error message to display if the compare fails.
     * @return {Promise} [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the page being visited has the expected title.
     */
    compareListContents: (world, locator, values, message = '') => module.exports.waitToBeVisible(world, locator).then(() => {
        const live = [];
        world.driver.findElements(locator).then((list) => list.map((item) => item.getText().then((text) => {
            live.push(text);
        }))).then(() => {
            expect(live, message !== '' ? message : 'Lists do not match').to.have.ordered.members(values);
        });
    }),

    /**
     * Find the element from a given list that matches the text provided and return that element.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the element whose text is being checked.
     * @param {string} label - The element text to match.
     * @param {Boolean} ignoredCase - whether to ignore the list item case
     * @param {Boolean} exactMatch - Changes the function to find an element containing the text
     * @return {WebElement|Promise} Either the array of [Selenium WebElement(s)]{@link http://seleniumhq.github.io/selenium/docs/api/javascript/module/selenium-webdriver/lib/webdriver_exports_WebElement.html} that match the element or the [Chai as Promised]{@link https://github.com/domenic/chai-as-promised} assertion that the array has more than zero elements.
     */
    pickOne: (world, locator, label, ignoredCase = true, exactMatch = true) => world.driver.findElement(() => promise.filter(
        world.driver.findElements(locator),
        (listItem) => world.driver.wait(until.elementIsVisible(listItem)).then((item) => {
            return item.getText().then((text) => {
                if (ignoredCase) {
                    text = text.toLowerCase();
                    label = label.toLowerCase();
                }
                if (exactMatch ? text.trim() === label : text.trim().includes(label)) {
                    return item;
                }
            });
        })).then((promised) => (promised.length > 0) ? promised :
        expect(promised, `Could not find element '${label}'`).to.have.length.above(0)
    )),

    /**
     * Convert a string to camel style string
     *
     * @param {string} str - The string to be converted to camelCase.
     * @return {string} The string converted to camelCase.
     */
    toCamelCase: (str) => {
        return str.toLowerCase()
            .replace('+', 'Plus')
            .replace(/\W/g, ' ')
            .replace(/\s+(.)/g, function ($1) {
                return $1.toUpperCase();
            })
            .replace(/\s/g, '');
    },

    /**
     * Retrieve data from the file specified.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {string} fileName - The core portion of the filename used to retrieve the data.
     * @param {string} keyName - The name of the data value to retrieve.
     * @return {string|string[]} The data being requested.
     */
    getDataValues: (world, fileName, keyName) => {
        // const application = world.config.application;
        const data = require(`../data/${fileName.replace(/\s/g, '')}Data`)(world);
        return get(data, keyName, '');
    },

    /**
     * Get text of an element
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} element - The {@link WebDriver} method that locates the elements whose texts are being checked.
     * @returns {Promise} Array of elements texts
     */
    getText: (world, element) => world.driver.findElement(element).then((element) => {
        return element.getAttribute('value').then((value) =>
            element.getText().then(
                (txt) => txt === null || txt === '' ? value === null ? '' : value : txt));
    }),

    /**
     * Get text of a set of elements
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {!By} elements - The {@link WebDriver} method that locates the elements whose texts are being checked.
     * @returns {Promise} Array of elements texts
     */
    getTexts: (world, elements) => world.driver.findElements(elements).then((elements) => {
        const texts = [];
        // expect(elements.length).to.be.gt(0, 'Did not find any elements!');
        elements.map((element) => {
            // element.getAttribute('value').then((value) =>
                element.getText().then((text) => {
                    texts.push(text);
                });
        });
        //If we do not assert that we have at least one text value, we must reject the promise or it causes cucumber to hang!
        // expect(texts.length).to.be.gt(0, 'Did not find any texts!');
        return Promise.resolve(texts);
    }).catch((error) => {
        // console.log(error);
        return Promise.reject(error)
    }),

    /**
     * Helper method to find the number of elements matching a locator and return the count.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The locator to identify all of the elements on the page.
     * @returns {string} - The size of the array of elements matching the locator.
     */
    getElementCount: (world, locator) => world.driver.findElements(locator).then((elements) => {
        return elements.length;
    }),

    /**
     * Scroll the page so that the element is visible on the view
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the elements whose texts are being checked.
     * @return {Promise} - Promise resolution that the browser javascript executor has changed the scroll position of the page.
     */
    scrollIntoView: (world, locator) => world.driver.findElement(locator).then((element) => {
        world.driver.executeScript('arguments[0].scrollIntoView(true);', element);
    }),

    /**
     * switch to any tab on the browser. If the index is less than 0, the first tab will be selected. If the index is greater the number of tabs, the last
     * tab will be selected
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {number} index - tab index
     * @return {Promise} - Promise resolution that the browser tab has been changed to the indexed tab.
     */
    switchToTab: (world, index) => world.driver.getAllWindowHandles().then((handles) => {
        world.driver.switchTo().window(handles[index < handles.length ? (index > 0 ? index : 0) : handles.length - 1]);
    }),

    /**
     * Switch to the next opened browser tab
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @return {Promise} - Promise resolution that the tab has switched to the subsequent tab of the browser.
     */
    switchToNextTab: (world) => world.driver.getAllWindowHandles().then((handles) => world.driver.getWindowHandle().then((handle) => {
        const index = handles.indexOf(handle);
        world.driver.switchTo().window(handles[(index + 1) < handles.length ? index + 1 : handles.length - 1]);
    })),

    /**
     * Opens a new tab and navigates to the specified URL.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {string} url - The specified URl to visit. Note that this must be formatted properly with https and www in the string.
     * @param {string} [title=''] title - Optional title field if you want to asset that the page title is correct after navigating to a page.
     * @return {Promise} - Promise resolution that a new tab has been opened to the specified URL.
     */
    openInNewTab: (world, url, title = '') => world.driver.executeScript('window.open()').then(() => {
        module.exports.switchToNextTab(world);
        module.exports.navigateToPage(world, url, title);
        module.exports.verifyPageUrl(world, url);
    }),

    /**
     * Creates a random @pps.io email address that is intended to be unique
     *
     * @returns {string} a string formatted into an email address with a random number.
     */
    randomEmail: () => {
        let string = '';
        const characters = '0123456789';

        for (let i = 0; i < 7; i++) {
            string += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return `qa+auto${string}@pps.io`;
    },

    /**
     * Creates a random string of numbers.
     *
     * @param {string} size - the length of the random number to be created
     * @returns {string} a string formatted into an email address with a random number.
     */
    randomNumber: (size) => {
        let random = '';
        const characters = '0123456789';

        for (let i = 0; i < size; i++) {
            random += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return random;
    },

    /**
     * Create a timestamp formatted as a string, optionally it can be dash separated if you pass the function true
     *
     * @param {boolean} separator - flag used to format the string with dashes
     * @returns {string} A string representing the current date and time
     */
    currentDateTime: (separator = false) => {
        if (separator) {
            return require('moment')().format('YYYY-MM-DD-HH-mm');
        } else {
            return require('moment')().format('YYYYMMDDHHmm');
        }
    },

    /**
     * Clear an input field. Do not use this on date fields or anything with values that persist after clearing.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - The {@link WebDriver} method that locates the elements whose texts are being checked.
     * @return {Promise} - Promise resolution that the field has been cleared.
     */
    clearField: (world, locator) => module.exports.waitToBeVisible(world, locator, `Could not locate the input field: ${locator}`).then((field) => {
        return field.clear().then(() => field.getAttribute('value').should.become('', `Could not clear the input field: ${locator}`));
    }),

    /**
     * Hover over an element and verify if the expected element is visible
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {!(By|Function)} hover - element locator that will be hovered on
     * @param {!(By|Function)} elementClick - expected element that will be visible after hovering
     * @return {Promise} Assert that the expected element is visible when hover the mouse over the element
     */
    hoverOverElementAndClick: (world, hover, elementClick) => world.driver.findElement(hover).then(element =>
        world.driver.actions().mouseMove(element).perform().then(() => module.exports.clickElement(world, elementClick))),

    /**
     * Hover over an element and verify if the expected element is visible
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {!(By|Function)} hover - element locator that will be hovered on
     * @param {!(By|Function)} elementClick - expected element that will be visible after hovering
     * @return {Promise} Assert that the expected element is visible when hover the mouse over the element
     */
    hoverOverElement: (world, hover) => module.exports.waitToBeLocated(world, hover).then((element) => {
        world.driver.actions().mouseMove(element).perform();
    }),

    /**
     * Get a random String
     * @param {number} size - length of the string
     * @return {String} a string
     */

    randString: (size) => {
        let random = '';
        const characters = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz';

        for (let i = 0; i < size; i++) {
            random += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return random;
    },

    /**
     * Get the dimensions of the browser
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @return {!promise.Thenable<{width: number, height: number}>} The size of the browser for use with responsive layouts
     */
    getWindowSize: (world) => world.driver.manage().window().getSize(),

    /**
     * Wait until the element contains a specific text. Useful for element text that will change
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - element locator
     * @param {String} text - assertion text
     * @param {number} timeout - timeout milliseconds
     * @param {String} error - custom error
     */
    waitUntilTextContains: (world, locator, text, timeout = 15000, error = null) =>
        world.driver.findElement(locator).then(element => {
            world.driver.wait(until.elementIsVisible, timeout,
                error === null ? 'Timeout: The element is not visible after ' + timeout / 1000 : error).then(() =>
                world.driver.wait(until.elementTextContains(element, text), timeout,
                    error === null ? 'Timeout: The element is not visible after ' + timeout / 1000 + ' seconds or ' +
                        `the text does not contains ${text}` : error));
        }),

    /** check if attribute is present for an element
     *
     * @param world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param locator- element locator
     * @param attribute- expected attribute
     */
    verifyAttributePresence: (world, locator, attribute) => {
        world.driver.findElement(locator).getAttribute(attribute).then((result) => {
            if (result === null) {
                result = 'false';
            }
            expect(result).to.equal('true');
        });
    },

    /**
     * Get an attribute of an element
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - element locator
     * @param {String} attribute - element attribute
     * @return {Promise}
     */
    getElementAttribute: (world, locator, attribute) => world.driver.findElement(locator).then(element => element.getAttribute(attribute)),

    /**
     * Resolve if the first promise of the promises array is resolved. Reject if all the promises are rejected
     * @param {Array<Promise>} promises - Array of Promises
     * @return {Promise}
     */
    waitForFirstResolve: (promises) => {
        const reverse = p => new Promise((resolve, reject) => Promise.resolve(p).then(reject, resolve));
        return reverse(Promise.all(promises.map(reverse)));
    },

    /**
     * Get a Css Value of an element
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - element locator
     * @param {String} prop - element css style property
     * @return {Promise}
     */
    getElementCssValue: (world, locator, prop) => module.exports.waitToBeVisible(world, locator).then(
        element => element.getCssValue(prop)),

    /**
     * Convert a rgba value to hex value
     * @param {String| Array<number>} value - rgba value
     */
    rgbaToHex: (value) => {
        let result = '#';
        if (typeof value === 'string')
            value = value.match(/\d+,\s*\d+,\s*\d+,\s*\d*/)[0].split(/\s*,\s*/);
        value.forEach((val, index) => {
            if (index < 4)
                result += parseInt(val).toString(16).padStart(2, '0');
            else if (index === 4)
                result += Math.round(parseInt(val) * 255).toString(16).padStart(2, '0');
        });
        return result;
    },
    /**
     * Wait for the page title contains the given text
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {String} text - given text to assert
     * @param {number} timeout - timeout
     * @param {String} error - Custom error to show when fail
     * @return {Promise}
     */
    waitUntilTitleContains: (world, text, timeout = 15000, error = null) =>
        world.driver.wait(until.titleContains(text), timeout,
            error === null ? new Error(`Timeout: The title does not contain ${text} after ` + timeout / 1000 + ' seconds') : new Error(error)),

    /** Press the return button for when a field has no submit button.
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {method} locator - element in focus. The same one you typed into with enterText
     */
    pressReturn: (world, locator) => {
        return world.driver.findElement(locator).then(element => element.sendKeys(Key.RETURN));
    },


    /** Refresh the browser window. Helpful for mxm because it has no app-level refresh button and can be slow to add to the tables
     *
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @return {promise} - Lets you know when the refresh is complete
     */
    refreshPage: (world) => {
        world.driver.navigate().refresh();
        module.exports.waitSeconds(world, 7);
    },
    /**
     * Generate a unique Id
     * @return {String}
     */
    generateId: () => uuid(),

    /**
     * Get the index of an element that have the text match the given table
     * @param {object} world - The custom [Cucumber World]{@link https://github.com/cucumber/cucumber-js/blob/master/docs/support_files/world.md} instance.
     * @param {!(By|Function)} locators - element locators
     * @param {String} value - value of the element that want to find the index of
     * @return {Promise} Assert that the index of the element is found
     */
    getElementIndex: (world, locators, value) => module.exports.getTexts(world, locators).then((texts) => {
        texts.indexOf(value) === -1 ? Promise.reject(new Error(`${texts.toString()} does not contains ${value}`)) : texts.indexOf(value) + 1;
    }),

};
